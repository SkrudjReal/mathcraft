import mathcraft

mathcraft.math()